import java.util.Scanner;
import java.util.Arrays;

public class VectorSort {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Input Format:
        // N d
        // N lines with d doubles per line
        int N = sc.nextInt(); // Number of vectors
        int d = sc.nextInt(); // Dimension of vectors
        double [] coords = new double[d];
        Vector[] vec = new Vector[N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < d; j++) {
                coords[j] = sc.nextDouble();
            }
            vec[i] = new Vector(coords);
        }
        Arrays.sort(vec);
        for (Vector v: vec) {
            System.out.println(v);
        }
    }
}
