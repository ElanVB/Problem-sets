import java.util.Arrays;
public class Vector implements Comparable<Vector>{

    private final double[] coords;

    public Vector(double[] a) {
        coords = new double[a.length];
        for (int i = 0; i < a.length; i++)
            coords[i] = a[i];
    }

    public Vector plus(Vector b) {
        double[] c = new double[coords.length];
        for (int i = 0; i < coords.length; i++)
            c[i] = coords[i] +b.coords[i];
        return new Vector(c);
    }

    public Vector times(double t) {
        double[] c = new double[coords.length];
        for (int i = 0; i < coords.length; i++)
            c[i] = t * coords[i];
        return new Vector(c);
    }

    public Vector minus(Vector b) {
        return this.plus(b.times(-1.0));
    }

    public double dot(Vector b) {
        double sum = 0.0;
        for (int i = 0; i < coords.length; i++)
            sum = sum + (coords[i] * b.coords[i]);
        return sum;
    }

    public double magnitude() {
        return Math.sqrt(this.dot(this));
    }

    public Vector direction() {
        return this.times(1/this.magnitude());
    }

    public double cartesian(int i) {
        return coords[i];
    }

    public String toString() {
        // Poor style doing this with Strings, since they are immutable
        // Better approach is to use StringBuilder class!
        String ans = "(";
        for (int i = 0; i < coords.length - 1; i++)
            ans = ans + coords[i] + ", ";
        assert coords.length > 0;
        ans = ans + coords[coords.length-1]+")";
        return ans;
    }

    public boolean equals(Object o) {
        if (!(o instanceof Vector))
            return false;
        return Arrays.equals(coords, ((Vector) o).coords);
    }

    public int compareTo(Vector b) {
        double a = this.magnitude() - b.magnitude();
        if (a > 0) return 1;
        if (a < 0) return -1;
        return 0;
    }
}
