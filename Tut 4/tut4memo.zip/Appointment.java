/*
Paragraph on immutability should be here.
*/
import java.util.Date;

public class Appointment {
    private Date date; // Date class is mutable!
    private String contact; // String already immutable

    public Appointment(Date date, String contact) {
        setDate(date); 
        setContact(contact);
    }

    public String getContact() {
        return contact;
    }

    private void setContact(String contact) {
        this.contact = contact;
    }

    /* This method is fundamentally flawed: one can not expose a mutable member and
       maintain immutability.  The simple "solution" followed here is removing the method (alternatively making
       it private, but not much purpose to that.)  The alternative is to replace Date by an immutable type - see textbook
       exercise 3.3.23.
    
        public Date getDate() {
        return date;
    } */ 

    private void setDate(Date date) {
        this.date = new Date(date.getTime());
    }

    public String toString() {
        return contact + " - " + date.toString();
    }
}
