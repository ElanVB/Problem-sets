import java.util.Scanner;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.IOException;


public class Weather {

    public static void main(String[] args) {
        String website = "http://weather.sun.ac.za/home.php";
        String content = null;
        try {
            URL url = new URL(website);
            Scanner sc = new Scanner(url.openStream(), "UTF-8");
            sc.useDelimiter("\\A");
            content = sc.next();
            //Alternatively:
            //content = new Scanner(new URL(website).openStream(), "UTF-8").useDelimiter("\\A").next();
            // TODO: Should close resources carefully!
        } catch (MalformedURLException e) {
            System.err.println("Invalid URL: "+website);
        } catch (IOException e) {
            System.err.println("Error downloading "+website);
        }
        // TODO: Deal with cases where we have something, but not the actual weather report
        System.out.print("Forecast for tomorrow: ");
        int maxLoc = content.indexOf("Max", 0); // Today's max so far
        maxLoc = content.indexOf("Max", maxLoc+1); // Today's forecast max
        maxLoc = content.indexOf("Max", maxLoc+1); // Tomorrow's max forecast - BINGO
        int endMaxLoc = content.indexOf("<br", maxLoc);
        String forecast = content.substring(maxLoc, endMaxLoc);
        System.out.println(forecast);
    }

}
