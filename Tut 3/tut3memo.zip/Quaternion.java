public class Quaternion {

/*
Implementation of an immutable Quaternion data type.

public class Quaternion
-----------------------
            Quaternion(double a0, double a1, double a2, double a3) : constructs a quaternion from the given vector components
Quaternion  scale(double c)     : multiplies this quaternion by the scalar c
Quaternion  plus(Quaternion q)  : adds this quaternion to q
double      norm()              : returns the norm of this quaternion
Quaternion  conjugate()         : returns the conjugate of this quaternion
Quaternion  times(Quaternion q) : multiplies this quaternion by q
Quaternion  inverse()           : returns the inverse of this quaternion.  Behaviour not specified for the zero vector.
Quaternion  over(Quaternion q)  : divides this quaternion by q.  Behaviour not specified for the zero vector.
String      toString()          : returns a string representation of this quaternion
*/

    private final double a0, a1, a2, a3, sqnorm;

    public Quaternion(double a0, double a1, double a2, double a3) {
        this.a0 = a0;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        sqnorm = a0*a0+a1*a1+a2*a2+a3*a3;

    }

    public Quaternion scale(double c) {
        return new Quaternion(c*a0, c*a1, c*a2, c*a3);
    }

    public Quaternion plus(Quaternion q) {
        return new Quaternion(a0+q.a0, a1+q.a1, a2+q.a2, a3+q.a3);
    }

    public double norm() {
        return Math.sqrt(sqnorm);
    }

    public Quaternion conjugate() {
        return new Quaternion(a0, -a1, -a2, -a3);
    }

    public Quaternion times(Quaternion q) {
        double ans0 = a0*q.a0-a1*q.a1-a2*q.a2-a3*q.a3;
        double ans1 = a0*q.a1-a1*q.a0+a2*q.a3-a3*q.a2;
        double ans2 = a0*q.a2-a1*q.a3+a2*q.a0+a3*q.a1;
        double ans3 = a0*q.a3+a1*q.a2-a2*q.a1+a3*q.a0;
        return new Quaternion(ans0, ans1, ans2, ans3);
    }

    public Quaternion inverse() {
        // Note: this fails if the Quaternion is the zero vector!
        if (sqnorm == 0) {
            throw new RuntimeException("Failure: taking inverse of zero");
        }
        return conjugate().scale(1/sqnorm);
    }

    public Quaternion over(Quaternion q) {
        return times(q.inverse());
    }

    public String toString() {
        return a0 + " + " + a1 + "i + " + a2 + "j + " + a3 + "k";
    }

    public static void main(String[] args) {
        // TODO: Add more test code!
        Quaternion a = new Quaternion(3.0, 1.0, 0.0, 0.0);
        System.out.println("a = " + a);

        Quaternion b = new Quaternion(0.0, 5.0, 1.0, -2.0);
        System.out.println("b = " + b);

        Quaternion c = new Quaternion(0.0, 0.0, 0.0, 0.0);
        System.out.println("c = " + c);

        System.out.println("2*a  = " + a.scale(2));
        System.out.println("norm(a)  = " + a.norm());
        System.out.println("conj(a)  = " + a.conjugate());
        System.out.println("a + b    = " + a.plus(b));
        System.out.println("a * b    = " + a.times(b));
        System.out.println("b * a    = " + b.times(a));
        System.out.println("a / b    = " + a.over(b));
        System.out.println("a^-1     = " + a.inverse());
        System.out.println("a^-1 * a = " + a.inverse().times(a));
        System.out.println("a * a^-1 = " + a.times(a.inverse()));
        //System.out.println("c^-1: should fail:" + c.inverse());
        //System.out.println("b/c should fail:" + b.over(c));
    }

}
