import java.awt.Color;

public class Rotation {
    public static void main(String[] args) {
        String filename = args[0];
        // Alternatively, use Math.toRadians
        double theta = Double.parseDouble(args[1])/180.0*Math.PI; // Convert from degrees to radians
        Picture source = new Picture(filename);
        int w = source.width();
        int h = source.height();
        int cx = w / 2;
        int cy = h / 2;
        double cos_minus_theta = Math.cos(-theta);
        double sin_minus_theta = Math.sin(-theta);
        Picture target = new Picture(w, h);

        for (int tx = 0; tx < w; tx++) {
            for (int ty = 0; ty < h; ty++) {
              int delta_x = tx - cx;
              int delta_y = ty - cy;
                // The formulas in the tutorial for getting the target
                // location from the source location can be swapped around 
                // to get the source location from the target location
                // if we realise that we must then rotate by -theta instead.              
                int sx = (int)(delta_x*cos_minus_theta - delta_y*sin_minus_theta + cx);
                int sy = (int)(delta_x*sin_minus_theta + delta_y*cos_minus_theta + cy);
                Color color;
                if ((sx < 0) || (sx >= w)) color = StdDraw.BLACK;
                else if ((sy < 0) || (sy >= h)) color = StdDraw.BLACK;
                else color = source.get(sx, sy);
                target.set(tx, ty, color);
            }
        }

        source.show();
        target.show();
    }
}
