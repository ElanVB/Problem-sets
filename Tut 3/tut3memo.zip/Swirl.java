import java.awt.Color;

public class Swirl {
  public static double dist(double x, double y, double x0, double y0) {
    double delta_x, delta_y;
    delta_x = x-x0;
    delta_y = y-y0;
    
    return Math.sqrt(delta_x*delta_x + delta_y*delta_y);
  }
  
    public static void main(String[] args) {
        String filename = args[0];
        Picture source = new Picture(filename);
        int w = source.width();
        int h = source.height();
        int cx = w / 2;
        int cy = h / 2;
        Picture target = new Picture(w, h);

        for (int tx = 0; tx < w; tx++) {
            for (int ty = 0; ty < h; ty++) {
              double theta = Math.PI / 256 * dist(tx, ty, cx, cy);
              double cos_minus_theta = Math.cos(theta);
              double sin_minus_theta = Math.sin(theta);
              int delta_x = tx - cx;
              int delta_y = ty - cy;
                // The formulas in the tutorial for getting the target
                // location from the source location can be swapped around 
                // to get the source location from the target location
                // if we realise that we must then rotate by -theta instead.              
                int sx = (int)(delta_x*cos_minus_theta - delta_y*sin_minus_theta + cx);
                int sy = (int)(delta_x*sin_minus_theta + delta_y*cos_minus_theta + cy);
                Color color;
                if ((sx < 0) || (sx >= w)) color = StdDraw.BLACK;
                else if ((sy < 0) || (sy >= h)) color = StdDraw.BLACK;
                else color = source.get(sx, sy);
                target.set(tx, ty, color);
            }
        }

        source.show();
        target.show();
    }
}
