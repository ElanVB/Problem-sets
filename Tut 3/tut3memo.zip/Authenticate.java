public class Authenticate {

    public static boolean checkConditions(String input) {
        if (input.length() < 8) return false;
        boolean digitPresent = false;
        boolean upperCasePresent = false;
        boolean lowerCasePresent = false;
        boolean nonAlphanumericPresent = false;
        for (int i=0; i< input.length(); i++) {
            char c = input.charAt(i);
            // Alternative: use methods in Character class, such as
            // Character.isDigit and Character.isLowerCase
            if (c >= '0' && c <= '9') {
                digitPresent = true;
                continue;
            }
            if (c >= 'A' && c <= 'Z') {
                upperCasePresent = true;
                continue;
            }
            if (c >= 'a' && c <= 'z') {
                lowerCasePresent = true;
                continue;
            }
            nonAlphanumericPresent = true;
        }
        if (digitPresent && upperCasePresent && lowerCasePresent && nonAlphanumericPresent) return true;
        return false;
    }

    public static void main(String[] args) {
        String[] inputs = {"hello", "", "123456", "Hello", "H3ll0J0hnny!", "H3ll0J0hnny", "H0wz1t!"};
        boolean[] expected = {false, false, false, false, true, false, false};
        // TODO: make this test suite more extensive
        for (int i = 0; i < inputs.length; i++) {
            System.out.println("Expecting "+expected[i]+", got: "+checkConditions(inputs[i]));
        }
    }
}
