public class Visualize {
    public static void main(String[] args) {
        int N    = Integer.parseInt(args[0]);
        if (N < 5) {
            System.out.println("Mazes too small");
            return;
        }
        int M    = Integer.parseInt(args[1]);

        StdDraw.show(0);
        // repeatedly created N-by-N matrices and display them using standard draw
        for (int i = 0; i < M; i++) {
            boolean[][] open = RandomMaze.getMaze(N);
            int start_i, start_j, end_i, end_j;
            do {
              start_i = StdRandom.uniform(N);
              start_j = StdRandom.uniform(N);
            } while (!open[start_i][start_j]);
            do {
              end_i = StdRandom.uniform(N);
              end_j = StdRandom.uniform(N);
            } while (!open[end_i][end_j] || (end_i==start_i && end_j==start_j));
            StdDraw.clear();
            StdDraw.setPenColor(StdDraw.BLACK);
            Maze.show(open, false, 0.5);
            boolean[][] path = Maze.path(open, start_i, start_j, end_i, end_j);
            StdDraw.setPenColor(StdDraw.RED);
            Maze.show(path, true, 0.3);
            Maze.drawStartEnd(open,start_i, start_j, end_i, end_j);
            StdDraw.show(2000);
        }
    }
}
