public class Maze {
    // given an N-by-N matrix of open sites, a starting position and an ending
    // position, return an N-by-N matrix containing a path from the starting
    // position to the ending position.
    public static boolean[][] path(boolean[][] open, 
                                   int start_i, int start_j, 
                                   int end_i, int end_j) {
        int N = open.length;
        boolean[][] visited = new boolean[N][N];
        return path(open, visited, start_i, start_j, end_i, end_j);
    }

    // determine set of full sites using depth first search
    public static boolean[][] path(boolean[][] open, boolean[][] visited, int i, int j, int end_i, int end_j) {
        int N = open.length;

        // base cases
        if (i < 0 || i >= N) return null;    // invalid row
        if (j < 0 || j >= N) return null;    // invalid column
        if (!open[i][j]) return null;        // not an open site
        if (visited[i][j]) return null;      // already marked as visited
        
        // mark i-j as visited
        visited[i][j] = true;

        if ((i == end_i) && (j == end_j)) {
          // We've arrived at our destination.
          boolean[][] path_result = new boolean[N][N];
          path_result[i][j] = true;
          return path_result;
        }


        boolean[][] path_result;
        
        path_result = path(open, visited, i+1, j, end_i, end_j);   // down
        if (path_result != null) {
          path_result[i][j] = true;
          return path_result;
        }
        path_result = path(open, visited, i, j+1, end_i, end_j);   // right
        if (path_result != null) {
          path_result[i][j] = true;
          return path_result;
        }
        path_result = path(open, visited, i, j-1, end_i, end_j);   // left
        if (path_result != null) {
          path_result[i][j] = true;
          return path_result;
        }
        path_result = path(open, visited, i-1, j, end_i, end_j);   // up
        if (path_result != null) {
          path_result[i][j] = true;
          return path_result;
        }
        return null;
    }

    // draw the N-by-N boolean matrix to standard draw
    public static void drawStartEnd(boolean[][] a, 
                                      int start_i, int start_j,
                                      int end_i, int end_j) {
        int N = a.length;
        StdDraw.setXscale(-1, N);
        StdDraw.setYscale(-1, N);
        
        StdDraw.setPenColor(StdDraw.GREEN);
        StdDraw.filledSquare(start_j, N-start_i-1, .4);
        StdDraw.setPenColor(StdDraw.YELLOW);
        StdDraw.filledSquare(end_j, N-end_i-1, .4);
    }
    
    // draw the N-by-N boolean matrix to standard draw
    public static void show(boolean[][] a, boolean which, double size) {
        int N = a.length;
        StdDraw.setXscale(-1, N);
        StdDraw.setYscale(-1, N);
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                if (a[i][j] == which)
                    StdDraw.filledSquare(j, N-i-1, size);
    }

/*
    // test client
    public static void main(String[] args) {
        boolean[][] open = StdArrayIO.readBoolean2D();
        StdArrayIO.print(flow(open));
        StdOut.println(percolates(open));
    }
*/
}
