import java.awt.Color;

public class FieldLines {

  private final static double RADIUS = 0.001;
  private final static double STEP = 0.0001;

  private final static int SIZE = 800;
  private static Picture pic = new Picture(SIZE, SIZE);
  private static Charge[] charges;

  public static void readCharges() {
    // read in N point charges
    int N = StdIn.readInt();
    
    charges = new Charge[N];
    for (int k = 0; k < N; k++) {
      double x0 = StdIn.readDouble();
      double y0 = StdIn.readDouble();
      double q0 = StdIn.readDouble();
      charges[k] = new Charge(x0, y0, q0);
    }
  }
  
  public static void drawFieldLine(Charge source, double angle) {
    if (source.getQ() == 0) return; // What's the point of a point charge with zero charge?

    double delta_x = Math.cos(angle) * RADIUS;
    double delta_y = Math.sin(angle) * RADIUS;
    double curx = source.getX()+delta_x;
    double cury = source.getY()+delta_y;

    while (true) {
      // First, check if we are off the screen.
      if ((curx < 0) || (curx >= 1)) return; // We are going offscreen, stop drawing.
      if ((cury < 0) || (cury >= 1)) return; // We are going offscreen, stop drawing.
      
      double fieldx = 0;
      double fieldy = 0;
      // Second, calculate field strength and direction.
      for (int i = 0 ; i < charges.length ; i++) {
        Charge other = charges[i];
        double fieldstrength = other.potentialAt(curx, cury);
        double diffx = curx-other.getX();
        double diffy = cury-other.getY();
        double distance = Math.sqrt(diffx*diffx+diffy*diffy);
        fieldx += diffx * fieldstrength/distance;
        fieldy += diffy * fieldstrength/distance;
        if (distance < STEP) return; // We are close to another charge. We are finished drawing.
      }

      // Draw a new pixel
      int x = (int)(curx * pic.width());
      int y = pic.height() - 1 - (int)(cury * pic.height());
      pic.set(x, y, Color.WHITE);  // Field lines in white
      
      // Update location using field strength
      if (fieldx == 0 && fieldy == 0) return; // The field strength is zero, so we can't go anywhere :(
      double distance = Math.sqrt(fieldx*fieldx+fieldy*fieldy);
      int adjustment = (source.getQ() > 0? 1: -1); // Move in opposite direction for negative charges
      curx += (fieldx/distance)*STEP*adjustment;
      cury += (fieldy/distance)*STEP*adjustment;
    }
  }
  
  public static void drawFieldLines() {
    for (int i = 0 ; i < charges.length ; i++) {
      for (int n = 0 ; n < 10 ; n++) {
        double angle = 2 * Math.PI / 10 * n;
        drawFieldLine(charges[i], angle);
      }
    }
  }

  public static void drawPotential() {
    // compute the potential at each point and plot in colour
    int N = charges.length;
    for (int i = 0; i < SIZE; i++) {
      for (int j = 0; j < SIZE; j++) {
        double V = 0.0;
        for (int k = 0; k < N; k++) {
          double x = 1.0 * i / SIZE;
          double y = 1.0 * j / SIZE;
          V += charges[k].potentialAt(x, y);
        }
        V = 128 + V / 2.0e10;
        int t = 0;
        if      (V <   0) t = 0;
        else if (V > 255) t = 255;
        else              t = (int) V;
        // In textbook, we used the below for grayscale:
        // Color c = new Color(t, t, t);
        // The below choice of color makes charges colours range
        // from red (postive) to blue (negative), with green for neutral:
        Color c = Color.getHSBColor(t * (2.0f / 3.0f / 255.0f), .9f, .9f);
        pic.set(i, SIZE-1-j, c);
      }
    }    
  }
  
  public static void main(String[] args) {
    readCharges();
    drawPotential();
    drawFieldLines();
    pic.show();
  }
}
