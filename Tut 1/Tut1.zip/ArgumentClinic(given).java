public class ArgumentClinic {
    public static void main(String[] args) {
        if (args.length == 0) System.out.println("*crickets*");
        if (args.length == 1) System.out.println("Palin is arguing with themself.");
        if (args.length == 2) System.out.println("Palin is having an argument with Cleese.");
        if (args.length == 3) System.out.println("Much hilarity ensues.");
        if (args.length == 4) System.out.println("Much hilarity ensues.");
    }
}
