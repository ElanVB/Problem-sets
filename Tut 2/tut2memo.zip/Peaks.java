import java.util.Scanner;

public class Peaks
{
    public static void main(String args[])
    {
        int minN, maxN, T;
        boolean simulate;
        double[] numPeaks;
        double[] maxPeakHeights;
        double[][] heights;
        Scanner sc = new Scanner(System.in);

        if (args.length < 2) {
            simulate = false;
            maxN = sc.nextInt();
            minN = maxN;
            T = 1;
        } else {
            simulate = true;
            maxN = Integer.parseInt(args[0]);
            minN = 1;
            T = Integer.parseInt(args[1]);
        }

        numPeaks = new double[maxN+1];
        maxPeakHeights = new double[maxN+1];
       
        for (int N = minN; N <= maxN; N++) {
            int M;
            double totalMaxPeakHeights = 0;
            int totalPeaks = 0;
            for (int t=0; t<T; t++) {
                // Set up (or read in) heights
                if (simulate) {
                    M = N;
                    heights = new double[N][M];
                    for (int i = 0 ; i < N ; i++) {
                        for (int j = 0 ; j < M ; j++) {
                            heights[i][j] = Math.random();
                        }
                    }
                } else {
                    M = sc.nextInt();
                    heights = new double[N][M];
                    for (int i = 0 ; i < N ; i++) {
                        for (int j = 0 ; j < M ; j++) {
                            heights[i][j] = sc.nextDouble();
                        }
                    }
                }
                // Do simulation
                double maxPeakHeight = 0;
                for (int i = 1 ; i < N-1 ; i++) {
                    for (int j = 1 ; j < M-1 ; j++) {
                        if ((heights[i][j] > heights[i-1][j])
                            && (heights[i][j] > heights[i+1][j])
                            && (heights[i][j] > heights[i][j-1])
                            && (heights[i][j] > heights[i][j+1])) {
                            // New peak found
                            totalPeaks++;
                            if (heights[i][j] > maxPeakHeight) {
                                // Highest on this terrain
                                maxPeakHeight = heights[i][j];
                            }
                            if (!simulate) {
                                System.out.println("" + (i+1) + 
                                                 "," + (j+1) + 
                                                 "->" + heights[i][j]);
                            }
                        }
                    }
                }
                totalMaxPeakHeights += maxPeakHeight;
            } 
            numPeaks[N] = ((double) totalPeaks)/T;
            maxPeakHeights[N] = totalMaxPeakHeights/T;
        }
        // Print out results at end.  Array actually not needed, however.
        if (simulate) {
            for (int i=1; i<=maxN; i++) {
                System.out.printf("%3d %9.4f %8.6f\n", i, numPeaks[i], maxPeakHeights[i]);
            }
        }
    }
}
