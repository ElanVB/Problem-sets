public class RecursiveSquares
{
  public static void drawSquaresFront(double x, double y, double size, int level) {
    if (level == 0) return;
    
    drawSquaresFront(x - size, y - size, size / 2.2, level-1);  // bottom-left
    drawSquaresFront(x + size, y - size, size / 2.2,  level-1); // bottom-right
    drawSquaresFront(x - size, y + size, size / 2.2,  level-1); // top-left
    drawSquaresFront(x + size, y + size, size / 2.2,  level-1); // top-right
    
    StdDraw.setPenColor(StdDraw.GRAY);
    StdDraw.filledSquare(x, y, size);
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.square(x, y, size);
  }

  public static void drawSquaresOrder(double x, double y, double size, int level) {
    if (level == 0) return;
    
    // Draw the top squares first
    drawSquaresOrder(x - size, y + size, size / 2.2,  level-1); // top-left
    drawSquaresOrder(x + size, y + size, size / 2.2,  level-1); // top-right
    
    // Draw the bigger square next (this overlaps on the top ones)
    StdDraw.setPenColor(StdDraw.GRAY);
    StdDraw.filledSquare(x, y, size);
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.square(x, y, size);

    // Draw the bottom squares next (these overlap on the lower ones)
    drawSquaresOrder(x - size, y - size, size / 2.2, level-1);  // bottom-left
    drawSquaresOrder(x + size, y - size, size / 2.2,  level-1); // bottom-right
  }

  public static void drawSquaresRight(double x, double y, double size, int level) {
    if (level == 0) return;
    
    // Draw the top-left, bottom-left, bottom-right squares first
    drawSquaresRight(x - size, y + size, size / 2.2,  level-1); // top-left
    drawSquaresRight(x - size, y - size, size / 2.2, level-1);  // bottom-left
    drawSquaresRight(x + size, y - size, size / 2.2,  level-1); // bottom-right
    
    // Draw the bigger square next (this overlaps the already drawn ones)
    StdDraw.setPenColor(StdDraw.GRAY);
    StdDraw.filledSquare(x, y, size);
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.square(x, y, size);

    // Draw the top-right one last (on top of everything else)
    drawSquaresRight(x + size, y + size, size / 2.2,  level-1); // top-right
  }

  public static void drawSquaresShaded(double x, double y, double size, int level) {
    if (level == 0) return;
    
    // Draw the bigger square next (it becomes the bottom layer)
    StdDraw.setPenColor(StdDraw.GRAY);
    StdDraw.filledSquare(x, y, size);
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.square(x, y, size);

    // Draw the smaller squares on top of the larger
    drawSquaresShaded(x + size, y + size, size / 2.2,  level-1); // top-right
    drawSquaresShaded(x - size, y + size, size / 2.2,  level-1); // top-left
    drawSquaresShaded(x - size, y - size, size / 2.2, level-1);  // bottom-left
    drawSquaresShaded(x + size, y - size, size / 2.2,  level-1); // bottom-right
  }

  public static void main(String args[]) {
    int mode = Integer.parseInt(args[0]);
    int N = Integer.parseInt(args[1]);
    
    StdDraw.setXscale(0, 1);
    StdDraw.setYscale(0, 1);
    StdDraw.clear();
    
    if (mode == 1) drawSquaresFront(0.5, 0.5, 0.25, N);
    if (mode == 2) drawSquaresOrder(0.5, 0.5, 0.25, N);
    if (mode == 3) drawSquaresRight(0.5, 0.5, 0.25, N);
    if (mode == 4) drawSquaresShaded(0.5, 0.5, 0.25, N);
  }
}