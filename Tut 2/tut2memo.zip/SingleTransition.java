import java.util.Scanner;

public class SingleTransition {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();           // number of pages
        int[][] counts = new int[N][N];    // counts[i][j] = # links from page i to page j
        int[] outDegree = new int[N];      // outDegree[i] = # links from page i to anywhere

        // Accumulate link counts.  
        while (sc.hasNextInt())  {
            int i = sc.nextInt(); 
            int j = sc.nextInt(); 
             if (counts[i][j] == 0) {
              outDegree[i]++; 
              counts[i][j] = 1;
            }
        } 
        System.out.println(N + " " + N); 


        // Print probability distribution for row i. 
        for (int i = 0; i < N; i++)  {

            // Print probability for column j. 
            for (int j = 0; j < N; j++) {
                double p = .90*counts[i][j]/outDegree[i] + .10/N; 
                System.out.printf("%7.5f ", p); 
            } 
            System.out.println(); 
        } 
    } 
} 

/* Contents of eightpage.txt:
8
  0 1
  1 3 1 3
  1 2 1 2
  1 4
  2 3
  2 6
  2 5
  3 0
  3 5
  4 0
  4 2
  5 6
  5 7
  6 7
  7 3
  7 5
  
Results:
$ java Transition < eightpage.txt |java RandomSurfer 10000
 0.09980 0.10220 0.06460 0.16210 0.03190 0.20200 0.12450 0.21290
$ java Transition < eightpage.txt |java Markov 100
 0.10055 0.10300 0.06355 0.16463 0.03104 0.20163 0.12230 0.21330
$ java SingleTransition < eightpage.txt |java RandomSurfer 10000                                                        
 0.10380 0.10790 0.06430 0.15660 0.04550 0.19740 0.11740 0.20710
$ java SingleTransition < eightpage.txt |java Markov 100                                                                
 0.10319 0.10537 0.06396 0.15741 0.04411 0.19664 0.12018 0.20915
$ java Transition < threepage.txt |java RandomSurfer 10000                                                              
 0.29050 0.42420 0.28530
$ java Transition < threepage.txt |java Markov 100                                                                      
 0.28827 0.42246 0.28827
$ java SingleTransition < threepage.txt |java RandomSurfer 10000                                                        
 0.33190 0.33440 0.33370
$ java SingleTransition < threepage.txt |java Markov 100
 0.33300 0.33300 0.33300

Discussion:
-The RandomSurfer and Markov approaches give similar results in all cases, as expected.
-There is very little difference between Transition and SingleTransition on the eightpage example.
-On the threepage example, we can see quite a noticeable difference - the pages are identical under the SingleTransition system, but
differ markedly under the regular Transition system.
-Which one is preferable depends on what one believes multiple links to a page
on another page specifies.  This comment, or any other sensibly motivated
opinion on what seems better would be fine.
*/
