public class Histograms
{
  public static int[] histogram(int M, int[] numbers) {
    int[] hist = new int[M];
    
    for (int i: numbers) {
      if ((i < M) && (i >= 0)) {
        hist[i]++;
      }
    }
    
    return hist;
  }
}
