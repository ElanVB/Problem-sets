import java.util.Scanner;

public class TestHistogram {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean plot = (args.length > 0);
        int M = sc.nextInt();
        int N = sc.nextInt();
        int [] a = new int[N];
        for (int i=0; i<N; i++) {
            a[i] = sc.nextInt();
        }
        int[] ans = Histograms.histogram(M, a);
        for (int i: ans) {  // Java for-each loop for arrays
            System.out.print(i+" ");
        }
        System.out.println();
    }
}
