
/*************************************************************************
 *  Compilation: javac Erlang.java
 *  Execution:   java  Erlang N p
 *
 *  Compute the Erlang blocking probability, for example:
 *  B(10, 20.000000) = 0.537963
 *
 *************************************************************************/

public class Erlang {

  public static double recErlang(int N, double rho) {
    // Makes N recursive calls in total - for each call, N reduces by 1, until 0.
    double x;
    if (N == 0) return 1.0;
    x = rho * recErlang(N-1, rho);
    return x / (N + x);
  }

  public static double nonrecErlang(int N, double rho) {
    double y = 1;
    for (int n=1; n<=N; n++) {
        y = rho * y / ( n + rho * y);
    }
    return y;
  }

  // test client
  public static void main(String[] args) {

    // parse the command-line parameters
    int N = Integer.parseInt(args[0]);
    double rho = Double.parseDouble(args[1]);
    assert N   >= 0;
    assert rho >= 0.0;

    System.out.printf("Recursive: B(%d, %.6f) = %.6f\n", N, rho, recErlang(N, rho));
    System.out.printf("Non-recursive: B(%d, %.6f) = %.6f\n", N, rho, nonrecErlang(N, rho));
  }

}

