public class Circles {
    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        double prob = Double.parseDouble(args[1]);
        double minRadius = Double.parseDouble(args[2]);
        double maxRadius = Double.parseDouble(args[3]);

        for (int i=0; i<N; i++) {
            double radius = minRadius + Math.random() * (maxRadius-minRadius);
            double x = Math.random();
            double y = Math.random();
            if (Math.random() < prob) {
                StdDraw.setPenColor(StdDraw.BLACK);
            } else {
                StdDraw.setPenColor(StdDraw.WHITE);
            }
            StdDraw.filledCircle(x, y, radius);
        }
    }
}
