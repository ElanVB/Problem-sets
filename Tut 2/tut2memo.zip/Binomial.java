public class Binomial
{
  public static double logFactorial(int N)
  {
    double log_result = 0.0;
    for (int i = 1; i <= N ; i++) log_result += Math.log(i);
    return log_result;
  }
  
  public static double binomial(int N, int k, double p)
  {
    double log_result = k*Math.log(p)
                      + (N-k)*Math.log(1-p)
                      + logFactorial(N)
                      - logFactorial(k)
                      - logFactorial(N-k);
     return Math.exp(log_result);
  }
  
  public static void main(String[] args)
  {
    int N = Integer.parseInt(args[0]);
    double p = Double.parseDouble(args[1]);
    
    double sum = 0.0;
    
    for (int i = 0 ; i <= N ; i++) {
      sum += binomial(N, i, p);
    }
    System.out.println("Total is "+sum);
  }
}
