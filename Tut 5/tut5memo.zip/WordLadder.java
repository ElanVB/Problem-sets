public class WordLadder {

    public static Graph constructGraphFromDict(In in) {
        Graph g = new Graph();
        while (!in.isEmpty()) {
            // read in words
            g.addVertex(in.readString());            
        }
        // StdOut.println("Added all words");
        for (String s: g.vertices()) {
            // add appropriate edges
            for (int i = 0; i< s.length(); i++) {
                String pre = s.substring(0, i);
                String post = s.substring(i+1, s.length());
                // Check for word by deleting i'th character.
                // Don't have to go other way because
                // edges go in both directions
                String candidate = pre + post;
                if (g.hasVertex(candidate)) g.addEdge(s, candidate);
                // Check for word by changing i'th character.
                for (char c = 'a'; c <= 'z'; c++) {
                    candidate = pre + ((Character) c).toString() + post;
                    if (g.hasVertex(candidate)) g.addEdge(s, candidate);
                }
                
            }
            // Monitor progress:
            // if (g.E() % 100 == 0) StdOut.println(g.E()+" edges on word "+s);
        }        
        return g;
    }

    public static void main(String[] args) {
        Graph g = constructGraphFromDict(new In(args[0]));
        //StdOut.println("Graph constructed with "+g.V()+" vertices and "+g.E()+" edges.  Enter your queries, or STOP to exit.");
        String source = StdIn.readString();
        while (!source.equals("STOP")) {
            PathFinder pf = new PathFinder(g, source);
            String target = StdIn.readString();
            if (pf.distanceTo(target) == Integer.MAX_VALUE) {
                StdOut.println("No path found.");
            } else {
                for (String v : pf.pathTo(target)) {
                    StdOut.print(v);
                    if (!v.equals(target)) StdOut.print(" -> ");
                }
                StdOut.println();
            }
            source = StdIn.readString();            
        }

    }
}
